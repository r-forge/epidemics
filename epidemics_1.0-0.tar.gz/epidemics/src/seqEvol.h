#include <math.h>
#include <time.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>


#define NEARZERO 0.0000000001
#define TRUE 1
#define FALSE 0

typedef short bool;



/*
   =============================
   === STRUCTURES DEFINITION ===
   =============================
*/



/*
   =================================
   === LOCAL AUXILIARY FUNCTIONS ===
   =================================
*/




/*
   ===============================
   === MAIN EXTERNAL FUNCTIONS ===
   ===============================
*/








/*
   =========================
   === TESTING FUNCTIONS ===
   =========================
*/

